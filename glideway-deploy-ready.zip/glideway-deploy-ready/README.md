# GlideWay Deploy-Ready Website

This is a Next.js website starter for **www.glidewayride.com**.

## What is included
- Branded homepage
- Booking section
- Features section
- About section
- Mission / Vision / Values
- Login / Register section
- Contact footer

## Local run
```bash
npm install
npm run dev
```

Then open:
```bash
http://localhost:3000
```

## Production build
```bash
npm install
npm run build
npm run start
```

## Deploy to Vercel
1. Create a new Vercel project.
2. Upload or connect this project repository.
3. Set the production domain to `www.glidewayride.com`.
4. In your domain registrar, point the domain DNS records to Vercel.

## Domain notes
Recommended setup:
- `glidewayride.com` redirects to `www.glidewayride.com`
- Add SSL in hosting provider settings

## Next recommended upgrades
- Add real login and registration backend
- Connect Stripe payments
- Add Google Maps live booking
- Add rider and driver dashboards
- Add admin and support pages
