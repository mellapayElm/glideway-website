import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'GlideWay | Ride Smoothly, Glide Easily',
  description:
    'GlideWayRide.com is a premium transportation platform built for comfort, safety, efficiency, and trust.',
  metadataBase: new URL('https://www.glidewayride.com'),
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
