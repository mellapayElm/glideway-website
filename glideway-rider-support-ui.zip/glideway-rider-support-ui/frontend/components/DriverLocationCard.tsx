import GoogleMapLive from "@/components/GoogleMapLive";

type Props = {
  pickup?: { lat: number; lng: number };
  dropoff?: { lat: number; lng: number };
  lat?: number;
  lng?: number;
  heading?: number;
  speedKph?: number;
};

export default function DriverLocationCard({ pickup, dropoff, lat, lng, heading, speedKph }: Props) {
  return (
    <div style={{
      border: "1px solid #e2e8f0",
      borderRadius: 20,
      padding: 20,
      background: "#fff",
      boxShadow: "0 2px 10px rgba(0,0,0,0.04)"
    }}>
      <h3 style={{ margin: 0, fontSize: 20 }}>Driver live location</h3>
      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <div><strong>Latitude:</strong> {lat ?? "--"}</div>
        <div><strong>Longitude:</strong> {lng ?? "--"}</div>
        <div><strong>Heading:</strong> {heading ?? "--"}</div>
        <div><strong>Speed (kph):</strong> {speedKph ?? "--"}</div>
      </div>
      <GoogleMapLive
        pickup={pickup}
        dropoff={dropoff}
        driver={lat !== undefined && lng !== undefined ? { lat, lng } : undefined}
      />
    </div>
  );
}