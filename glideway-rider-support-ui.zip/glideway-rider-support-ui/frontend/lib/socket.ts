import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

export function getTripsSocket(): Socket {
  if (!socket) {
    socket = io(`${process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3001"}/trips`, {
      transports: ["websocket"],
    });
  }
  return socket;
}

export function joinRideRoom(rideId: string) {
  const s = getTripsSocket();
  s.emit("room.join", { room: `ride:${rideId}` });
}

export function leaveRideRoom(rideId: string) {
  const s = getTripsSocket();
  s.emit("room.leave", { room: `ride:${rideId}` });
}