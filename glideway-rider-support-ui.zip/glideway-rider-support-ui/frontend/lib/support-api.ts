export async function sendRideMessage(rideId: string, body: string) {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3001";
  const res = await fetch(`${baseUrl}/api/v1/rides/${rideId}/messages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ body }),
  });

  if (!res.ok) {
    throw new Error("Failed to send message");
  }

  return res.json();
}

export async function startMaskedCall(rideId: string) {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3001";
  const res = await fetch(`${baseUrl}/api/v1/rides/${rideId}/calls/start`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (!res.ok) {
    throw new Error("Failed to start masked call");
  }

  return res.json();
}

export async function requestRefund(rideId: string, paymentId: string, reason: string, requestedMinor: number) {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3001";
  const res = await fetch(`${baseUrl}/api/v1/refunds`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ rideId, paymentId, reason, requestedMinor }),
  });

  if (!res.ok) {
    throw new Error("Failed to request refund");
  }

  return res.json();
}